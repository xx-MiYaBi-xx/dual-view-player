@echo off
chcp 65001 >nul
echo DualViewPlayer setup (internet connection required, about 200 MB download)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 (
  echo.
  echo Setup failed. Please check your internet connection and try again.
) else (
  echo.
  echo Setup finished. Open the "DualViewPlayer" folder and run DualViewPlayer.exe
)
pause
