const { app, BrowserWindow, ipcMain, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');

// Windows に HEVC 拡張機能やハードウェアデコーダーがあれば H.265 も再生を試みる
app.commandLine.appendSwitch('enable-features', 'PlatformHEVCDecoderSupport');

const ffmpegPath = app.isPackaged || fs.existsSync(path.join(process.resourcesPath, 'ffmpeg', 'ffmpeg.exe'))
  ? path.join(process.resourcesPath, 'ffmpeg', 'ffmpeg.exe')
  : 'ffmpeg';
const cacheDir = path.join(app.getPath('temp'), 'DualViewPlayer-cache');

function createWindow() {
  const win = new BrowserWindow({
    width: 1500, height: 1000, minWidth: 700, minHeight: 600,
    backgroundColor: '#0d1117',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
    },
  });
  Menu.setApplicationMenu(null);
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    if (input.key === 'F12') { win.webContents.toggleDevTools(); e.preventDefault(); }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

// ffmpeg で再生しやすい H.264/AAC の MP4 に変換（元ファイルは変更しない）
ipcMain.handle('transcode', async (event, srcPath, id) => {
  try {
    const st = fs.statSync(srcPath);
    fs.mkdirSync(cacheDir, { recursive: true });
    const key = crypto.createHash('sha1').update(srcPath + '|' + st.size + '|' + st.mtimeMs).digest('hex').slice(0, 16);
    const out = path.join(cacheDir, key + '.mp4');
    if (fs.existsSync(out) && fs.statSync(out).size > 0) return { ok: true, url: pathToFileURL(out).href };

    const tmp = out + '.part.mp4';
    const args = ['-y', '-hide_banner', '-i', srcPath,
      '-map', '0:v:0', '-map', '0:a:0?',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-g', '10',
      '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      '-fps_mode', 'passthrough',
      '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', tmp];
    await new Promise((resolve, reject) => {
      const p = spawn(ffmpegPath, args, { windowsHide: true });
      let dur = 0, tail = '';
      const toSec = (h, m, s) => (+h) * 3600 + (+m) * 60 + parseFloat(s);
      p.stderr.on('data', (d) => {
        const s = d.toString(); tail = (tail + s).slice(-2000);
        const dm = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(s);
        if (dm && !dur) dur = toSec(dm[1], dm[2], dm[3]);
        const tm = [...s.matchAll(/time=(\d+):(\d+):([\d.]+)/g)].pop();
        if (tm) {
          const t = toSec(tm[1], tm[2], tm[3]);
          event.sender.send('transcode-progress', { id, pct: dur ? Math.min(99, Math.round(t / dur * 100)) : null, time: t });
        }
      });
      p.on('error', reject);
      p.on('close', (code) => code === 0 ? resolve() : reject(new Error('ffmpeg が失敗しました（コード ' + code + '）\n' + tail.split('\n').slice(-4).join('\n'))));
    });
    fs.renameSync(tmp, out);
    return { ok: true, url: pathToFileURL(out).href };
  } catch (err) {
    return { ok: false, error: String(err.message || err) };
  }
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
