const { contextBridge, ipcRenderer, webUtils } = require('electron');
contextBridge.exposeInMainWorld('native', {
  pathOf: (file) => webUtils.getPathForFile(file),
  transcode: (srcPath, id) => ipcRenderer.invoke('transcode', srcPath, id),
  onProgress: (cb) => ipcRenderer.on('transcode-progress', (_e, d) => cb(d)),
});
