# Builds DualViewPlayer.exe (Electron + FFmpeg) next to this script.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$out  = Join-Path $root 'DualViewPlayer'
$tmp  = Join-Path $env:TEMP 'dvp-setup'
$electronUrl = 'https://github.com/electron/electron/releases/download/v33.2.0/electron-v33.2.0-win32-x64.zip'
$ffmpegUrl   = 'https://github.com/GyanD/codexffmpeg/releases/download/7.1/ffmpeg-7.1-essentials_build.zip'

if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Force $tmp | Out-Null

Write-Host '[1/4] Downloading Electron (about 115 MB)...'
Invoke-WebRequest $electronUrl -OutFile (Join-Path $tmp 'electron.zip')
Write-Host '[2/4] Downloading FFmpeg (about 90 MB)...'
Invoke-WebRequest $ffmpegUrl -OutFile (Join-Path $tmp 'ffmpeg.zip')

Write-Host '[3/4] Extracting...'
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
Expand-Archive (Join-Path $tmp 'electron.zip') $out
Rename-Item (Join-Path $out 'electron.exe') 'DualViewPlayer.exe'
Remove-Item (Join-Path $out 'resources\default_app.asar') -ErrorAction SilentlyContinue
Get-ChildItem (Join-Path $out 'locales') -Filter *.pak | Where-Object { $_.Name -notin @('ja.pak','en-US.pak') } | Remove-Item -Force
Expand-Archive (Join-Path $tmp 'ffmpeg.zip') (Join-Path $tmp 'ff')

Write-Host '[4/4] Assembling the app...'
Copy-Item (Join-Path $root 'app') (Join-Path $out 'resources\app') -Recurse
$ffdir = Get-ChildItem (Join-Path $tmp 'ff') -Directory | Select-Object -First 1
$dest = Join-Path $out 'resources\ffmpeg'
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item (Join-Path $ffdir.FullName 'bin\ffmpeg.exe') $dest
Copy-Item (Join-Path $ffdir.FullName 'LICENSE') $dest -ErrorAction SilentlyContinue
Copy-Item (Join-Path $root 'app\README-ja.txt') (Join-Path $out 'README-ja.txt')

Remove-Item $tmp -Recurse -Force
Write-Host ''
Write-Host 'Done. Run:  DualViewPlayer\DualViewPlayer.exe'
